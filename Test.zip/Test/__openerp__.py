# -*- coding: utf-8 -*-
{
    'name': 'Test',
    'version': '1.1',
    'category': '',
    'sequence': 1,
    'summary': '',
    'description': """Test""",
    'author': 'Hitesh',
    'website': '',
    'images': [],
    'depends': ['base','crm'],
    'data': ['views/lead_view.xml'],
    'demo': [],
    'test': [],
    'installable': True,
    'auto_install': False,
    'application': True,
    'price': 0.0,
    'currency': '',
    'license': ''
}
