from openerp import api, fields, models, _


class crm_lead(models.Model):
    _inherit = 'crm.lead'

    make_id = fields.Many2one('make', string='Make')
    model_id = fields.Many2one('model', string='Model')
    variant_id = fields.Many2one('variant', string='Variant')


    @api.onchange('make_id')
    def onchange_make(self):
        res={}
        if self.make_id:
            model_ids = self.env['model'].search([('make_id','=',self.make_id.id)])
            if len(model_ids)==1:
                self.model_id = model_ids.id
            else:
                res['domain'] = {'model_id':[('make_id','=',self.make_id.id)]}

        return res

    @api.onchange('model_id')
    def onchange_model(self):
        res = {}
        if self.model_id:
            variant_ids = self.env['variant'].search([('model_id', '=', self.model_id.id)])
            if len(variant_ids)==1:
                self.variant_id = variant_ids.id
            else:
                res['domain'] = {'variant_id': [('model_id', '=', self.model_id.id)]}

        return res

class Make(models.Model):
    _name = 'make'

    name = fields.Char('Make')

class Model(models.Model):
    _name = 'model'

    name = fields.Char('Model')
    make_id = fields.Many2one('make', string = 'Make')

class Variant(models.Model):
    _name = 'variant'

    name = fields.Char('Variant')
    model_id = fields.Many2one('model', string = 'Model')